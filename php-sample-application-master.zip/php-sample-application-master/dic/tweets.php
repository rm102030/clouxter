<?php

return new Service\TweetsService(
    require "config/db-connection.php"
);
