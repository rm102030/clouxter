<?php

namespace Entity;

class Tweet
{
    public $id;
    public $ts;
    public $userId;
    public $message;
}
