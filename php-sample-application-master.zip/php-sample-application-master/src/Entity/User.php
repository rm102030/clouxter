<?php

namespace Entity;

class User
{
    public $id;
    public $joined;
    public $name;
}
